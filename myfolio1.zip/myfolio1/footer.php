<div class="container-fluid">
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <div class="col-md-4 d-flex align-items-center">
        <a href="#" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1"><img src="./images/minilogo.png" alt="minilogo"></a> <span class="text-muted">© 2021 Company, Inc</span>
        </div>

        <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
        <li class="ms-3"><a class="text-muted" href="https://www.facebook.com/eldrine.arponadizas/"><i class="fa-brands fa-facebook"></i></a></li>
        <li class="ms-3"><a class="text-muted" href="https://myaccount.google.com/?hl=fil&utm_source=OGB&utm_medium=act&nlr=1"><i class="fa-solid fa-envelope"></i></a></li>
        <li class="ms-3"><a class="text-muted" href="https://www.youtube.com/@eldrineadizas4640/"><i class="fa-brands fa-youtube"></i></a></li>
        </ul>
    </footer>
</div>